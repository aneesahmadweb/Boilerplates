var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Anees_CheckoutField/js/model/shipping-save-processor/default'
        }
    }
};
