<?php


namespace Anees\ProductTabs\Block\Index;


use Magento\TestFramework\Event\Magento;

class Post extends \Magento\Framework\View\Element\Template
{



    public function execute(){


    }
}
