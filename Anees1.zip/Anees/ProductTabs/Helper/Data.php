<?php

namespace Anees\ProductTabs\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{

    /**
     * @var ScopeConfigInterface
     */
    public $scopeConfig;

    /**
     * UtilityCmsPage constructor.
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig
    ) {
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Get List Page Identifiers
     * @return array
     */
    public function isEnabled()
    {
        $homePageIdentifier = $this->scopeConfig->getValue(
            'tab/fa/enabled',
            ScopeInterface::SCOPE_STORE
        );


        return $homePageIdentifier;
    }
}
