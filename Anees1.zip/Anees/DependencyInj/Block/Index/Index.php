<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */


namespace Anees\DependencyInj\Block\Index;

use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Customer\Model\Customer;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

class Index extends Template
{
    /**
     * @var CollectionFactory
     */
    protected $_productCollectionFactory;

    protected $customer;
    /**
     * Constructor
     *
     * @param Context  $context
     * @param array $data
     */
    public function __construct(
        Context $context,
        Customer $customer,
        Product $prod,
        CollectionFactory $productCollectionFactory,
        array $data = []
    ) {
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->_prod = $prod;

        parent::__construct($context, $data);
    }

    public function showsomething(){

        return 'Any Dataa';
    }

/** Get full Products Collection**/
    public function getProductCollection()
    {
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->setPageSize(6);
        return $collection;
    }


    public function prod()
    {


    }
}

