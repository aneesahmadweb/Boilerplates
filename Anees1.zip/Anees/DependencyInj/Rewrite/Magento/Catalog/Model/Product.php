<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Anees\DependencyInj\Rewrite\Magento\Catalog\Model;
use Magento\Store\Model\ScopeInterface;

class Product extends \Magento\Catalog\Model\Product
{
    /**
     * @return string
     *
     */
    public function getName()
    {
        return parent::getName() . ' D-E !!';
    }






    /**
     * Get product price through type instance
     *
     * @return float
     */
    public function getPrice()
    {
        if ($this->_calculatePrice || !$this->getData(self::PRICE)) {
            return $this->getPriceModel()->getPrice($this);
        } else {
            return $this->getData(self::PRICE);
        }
    }


    /**
     * Check whether the product type or stock allows to purchase the product
     *
     * @return bool
     */
    public function isAvailable()
    {
        return $this->_catalogProduct->getSkipSaleableCheck() || $this->getTypeInstance()->isSalable($this);
    }

}

